# Discord Bot - Role Pinger

## Overview
A Discord bot that monitors a specific channel and pings a designated role whenever someone posts a message. Built with discord.js v14 with enterprise-grade stability and error handling.

## Current State
- **Status**: Fully functional and running with enhanced stability
- **Last Updated**: October 24, 2025
- **Framework**: discord.js v14.23.2
- **Runtime**: Node.js 20 with ES modules

## Features
- Monitors a specific Discord channel for new messages
- Pings a designated role when messages are posted (role mention only, no extra text)
- 5-second cooldown per guild/channel to prevent spam
- Ignores messages from the bot itself
- Environment variable configuration for security
- **Enhanced Stability Features:**
  - Automatic reconnection handling
  - Comprehensive error logging (errors, warnings, rate limits)
  - Shard disconnect/reconnect monitoring
  - Graceful shutdown handling (SIGINT/SIGTERM)
  - Status heartbeat monitoring every 5 minutes
  - Extended timeout handling (60 seconds)
  - Unhandled rejection and exception catching

## Project Structure
```
/
├── index.js         # Main bot code with stability enhancements
├── package.json     # Node.js dependencies and configuration
└── .gitignore       # Git ignore rules
```

## Environment Variables
The bot requires three environment secrets (configured in Replit Secrets):
- `TOKEN` - Discord bot token from Discord Developer Portal
- `CHANNEL_ID` - ID of the channel to monitor (currently: 1431154474638114961)
- `ROLE_ID` - ID of the role to ping (currently: 1431154632616316968)

## Required Discord Permissions
The bot needs these permissions in your Discord server:
- View Channels
- Read Messages/View Channels
- Send Messages
- Mention Roles (with the specific role made mentionable or bot having appropriate permissions)
- **Privileged Intents Required:**
  - Message Content Intent (must be enabled in Discord Developer Portal)

## How It Works
1. Bot connects to Discord using the provided token
2. Listens for new messages in all channels
3. When a message is posted in the watched channel:
   - Checks if cooldown has expired (5 seconds)
   - Sends a message pinging the specified role (just `<@&ROLE_ID>` with no extra text)
   - Updates the cooldown timer
4. Automatically handles disconnections and reconnects
5. Logs all errors and warnings for monitoring

## Stability & Reliability
The bot includes multiple layers of protection against crashes:
- **Network Issues**: Automatic Discord gateway reconnection
- **Rate Limiting**: Detection and logging of rate limit events
- **Shard Management**: Monitors shard health and reconnection status
- **Error Recovery**: Catches and logs all errors without crashing
- **Health Monitoring**: Regular heartbeat checks every 5 minutes
- **Graceful Shutdown**: Proper cleanup on process termination

## Running the Bot
The bot runs automatically via the "Discord Bot" workflow executing `node index.js`.

## Monitoring
Check the console logs to monitor:
- Connection status and ready events
- Error messages and warnings
- Heartbeat status every 5 minutes
- Disconnect/reconnect events
- Rate limit warnings

## Next Phase Enhancements
- Add command handler for dynamic channel/role configuration
- Implement multiple channel monitoring with different role assignments
- Add configurable cooldown periods per channel
- Create persistent logging system for ping events
- Add web dashboard for bot monitoring and configuration
- Implement allowedMentions restriction for enhanced security
