// index.js - pings a role whenever any message is sent in a specific channel
import { Client, GatewayIntentBits, Events } from "discord.js";

const token = process.env.TOKEN;
const WATCH_CHANNEL = process.env.CHANNEL_ID;
const ROLE_ID = process.env.ROLE_ID;
const COOLDOWN_MS = 5000; // 5 second cooldown per channel

if (!token || !WATCH_CHANNEL || !ROLE_ID) {
  console.error("Missing environment variables TOKEN, CHANNEL_ID, or ROLE_ID");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  failIfNotExists: false,
  rest: { timeout: 60000 }
});

const lastPing = new Map();

client.on(Events.MessageCreate, async (message) => {
  try {
    if (message.author.id === client.user?.id) return;
    if (!message.guild) return;
    if (message.channel.id !== WATCH_CHANNEL) return;

    const key = `${message.guild.id}:${WATCH_CHANNEL}`;
    const now = Date.now();
    const last = lastPing.get(key) || 0;
    if (now - last < COOLDOWN_MS) return;
    lastPing.set(key, now);

    await message.channel.send(`<@&${ROLE_ID}>`);
  } catch (err) {
    console.error("Handler error:", err);
  }
});

client.once(Events.ClientReady, () => {
  console.log(`Bot ready as ${client.user.tag}`);
  console.log(`Monitoring channel: ${WATCH_CHANNEL}`);
  console.log(`Pinging role: ${ROLE_ID}`);
});

client.on(Events.Error, (error) => {
  console.error("Discord client error:", error);
});

client.on(Events.Warn, (warning) => {
  console.warn("Discord client warning:", warning);
});

client.on(Events.Debug, (info) => {
  if (info.includes('heartbeat') || info.includes('Heartbeat')) {
    return;
  }
  console.debug("Debug:", info);
});

client.on(Events.ShardDisconnect, (event, shardId) => {
  console.warn(`Shard ${shardId} disconnected`, event);
});

client.on(Events.ShardReconnecting, (shardId) => {
  console.log(`Shard ${shardId} reconnecting...`);
});

client.on(Events.ShardResume, (shardId, replayedEvents) => {
  console.log(`Shard ${shardId} resumed, replayed ${replayedEvents} events`);
});

client.on(Events.ShardError, (error, shardId) => {
  console.error(`Shard ${shardId} error:`, error);
});

client.on(Events.RateLimit, (rateLimitData) => {
  console.warn("Rate limited:", rateLimitData);
});

process.on('unhandledRejection', (error) => {
  console.error("Unhandled promise rejection:", error);
});

process.on('uncaughtException', (error) => {
  console.error("Uncaught exception:", error);
});

process.on('SIGINT', () => {
  console.log("Received SIGINT, shutting down gracefully...");
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log("Received SIGTERM, shutting down gracefully...");
  client.destroy();
  process.exit(0);
});

setInterval(() => {
  console.log(`[Heartbeat] Bot status: ${client.ws.status} | Ready: ${client.isReady()}`);
}, 300000);

client.login(token).catch((error) => {
  console.error("Failed to login:", error);
  process.exit(1);
});
